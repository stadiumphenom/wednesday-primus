import os
import base64
import requests

GITHUB_API = "https://api.github.com"
HEADERS = {
    "Authorization": f"token {os.environ['GITHUB_TOKEN']}",
    "Accept": "application/vnd.github+json"
}
USERNAME = os.environ["GITHUB_USERNAME"]

def handler(request):
    repo = request.args.get("repo")
    url = f"{GITHUB_API}/repos/{USERNAME}/{repo}"
    r = requests.delete(url, headers=HEADERS)
    return {}, r.status_code